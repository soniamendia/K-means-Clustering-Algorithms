# Main Python script using the Cython module

K = 3  # Number of clusters
dimensionality = 2  # Dimensionality of data points (e.g., 2D)
dataset_size = 1000  # Size of the dataset (number of data points)

from kmeans_cython import kmeans_cython

